const sgMail = require('@sendgrid/mail');

exports.handler = async (event, context) => {
  // Enable CORS
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };

  // Handle preflight
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: "",
    };
  }

  // Only allow POST
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" }),
    };
  }

  try {
    const contactData = JSON.parse(event.body || "{}");
    
    // Basic validation
    if (!contactData.fullName || !contactData.email || !contactData.investmentType || !contactData.investmentAmount || !contactData.message) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Missing required fields" }),
      };
    }
    
    // Send email via SendGrid
    if (process.env.SENDGRID_API_KEY) {
      sgMail.setApiKey(process.env.SENDGRID_API_KEY);
      
      const msg = {
        to: 'info@madinimoyoni.co.uk',
        from: 'info@madinimoyoni.co.uk',
        subject: `New Investment Inquiry - ${contactData.investmentType}`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #1a365d;">New Investment Inquiry</h2>
            
            <div style="background: #f7fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3 style="color: #2d3748; margin-top: 0;">Contact Information</h3>
              <p><strong>Name:</strong> ${contactData.fullName}</p>
              <p><strong>Email:</strong> ${contactData.email}</p>
              <p><strong>Phone:</strong> ${contactData.phone || 'Not provided'}</p>
            </div>
            
            <div style="background: #fef5e7; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3 style="color: #2d3748; margin-top: 0;">Investment Details</h3>
              <p><strong>Investment Type:</strong> ${contactData.investmentType}</p>
              <p><strong>Investment Amount:</strong> ${contactData.investmentAmount}</p>
            </div>
            
            <div style="background: #f0fff4; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3 style="color: #2d3748; margin-top: 0;">Message</h3>
              <p style="white-space: pre-wrap;">${contactData.message}</p>
            </div>
            
            <div style="border-top: 1px solid #e2e8f0; padding-top: 20px; margin-top: 30px; color: #718096; font-size: 14px;">
              <p>This inquiry was submitted through the Madini Moyoni website contact form.</p>
              <p>Submitted at: ${new Date().toLocaleString()}</p>
            </div>
          </div>
        `,
      };
      
      try {
        await sgMail.send(msg);
        console.log('Email sent successfully to info@madinimoyoni.co.uk');
      } catch (emailError) {
        console.error('SendGrid email error:', emailError);
        // Continue anyway - we'll still return success
      }
    } else {
      console.warn('SENDGRID_API_KEY not configured - email not sent');
    }
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ 
        success: true, 
        message: "Thank you for your interest! We will contact you within 24 hours to discuss your investment.",
        id: Date.now().toString()
      }),
    };
  } catch (error) {
    console.error('Contact form error:', error);
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ 
        error: "Invalid form data", 
        details: error.message 
      }),
    };
  }
};